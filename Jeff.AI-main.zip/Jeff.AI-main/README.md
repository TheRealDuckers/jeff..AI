# Jeff.AI
This is a ***little*** project that we are working on, we are planing to get AI models running on here for some to use.
It will include some tools like a code "playground" and AI Chat and assistive features. And Games.

The main aim is to use a Server running an Ollama-based model and then using a webhook/pull request to allow it to communicate over Github.
